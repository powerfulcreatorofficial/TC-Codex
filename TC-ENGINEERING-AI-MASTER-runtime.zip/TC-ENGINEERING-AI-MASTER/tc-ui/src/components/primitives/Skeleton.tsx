import { cn } from "@/lib/cn";

export function Skeleton({ className }: { className?: string }) {
  return (
    <div
      className={cn(
        "animate-pulse rounded-md bg-surface-2",
        // Under reduced motion the shimmer is suppressed globally; keep a static block.
        "motion-reduce:animate-none",
        className,
      )}
      aria-hidden="true"
    />
  );
}
